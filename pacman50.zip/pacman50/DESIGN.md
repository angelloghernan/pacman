﻿## Background

I made this project with the goal to make it as close to the original Pac-Man
as possible within the time alloted.

With this in mind, I knew that a lot of effort would have to go into playtesting; for this reason, I decided to make the game in JavaScript so that I could easily share the game with my friends using a CS50 NodeJS server (through `http-server`).

Thanks to them, I was able to squash a good chunk of bugs (though I'm sure there are still a few -- there's only so much playtesting we could do, and this game has *a lot* going on every single frame. Even the original game has some [infamous](https://tcrf.net/Bugs:Pac-Man_%28Arcade%29) [bugs](https://www.youtube.com/watch?v=JLfugsoU3d0)!)

I also wanted to use JavaScript because I knew it would be relatively easy to get everything running compared to making games in most other languages. Phaser struck me as a relatively simple game engine to use, and also one with a lot of documentation available.

Finally, I wanted to get more familiar with JavaScript, since I had little experience with the language (though honestly, this didn't give me much practical experience, except for some knowledge of the language's idiosyncrasies).

## Technical Details

With all that in mind, the most interesting (and technical part) of this project was replicating the ghost AI; most of the code is boilerplate code trying to replicate animations or certain mechanics, so most of this section will be dedicated to the ghost AI with other aspects only briefly mentioned. More detail on those other aspects can be found in code comments.

Some invaluable sources for finding out this information were [this](https://gameinternals.com/understanding-pac-man-ghost-behavior) article by GameInternals and [this](https://www.youtube.com/watch?v=ataGotQ7ir8) video by Retro Game Mechanics Explained.

In short, the way the ghost AI works is by first picking a target tile. The way this target tile is picked is based on the "mode" the ghosts are in: when the ghosts are not vulnerable, they have two modes (scatter and chase). When vulnerable, they are put into the "frightened" mode. Finally, when they are eaten by Pac-Man, they are briefly put into another mode ("eaten" mode).

For "scatter" mode, the ghost AI picks a preset tile in one of the corners of the maze (this tile depends on the ghost; for example, Inky targets a tile just outside the right corner of the maze).

For "eaten" mode, the ghost AI picks a preset tile just outside the ghost "cage" area where they spawn. Once on the tile, the ghost moves down into the cage and respawns.

For "frightened" mode, the ghost AI actually does not use a target tile in the same way as the previous modes. Instead, it just picks a random direction to head in at each intersection (that is not the same direction they came from).

Finally, for "chase" mode, the AI chooses based on several factors based on the ghost. Put simply:

 - The red ghost will set its target tile as Pac-Man's position.
 - The pink ghost will target three tiles in front of where Pac-Man is
   chasing.
- The cyan ghost will choose a tile two tiles in front of where Pac-Man is facing, draw a line between Pac-Man and the red ghost, double this line's length, and choose the tile that the line points at

- The orange ghost will target Pac-Man just like the red ghost if he is more than eight tiles away from Pac-Man. If he is closer than eight tiles away, he will change his target to his same target from Scatter mode.

You can see how the ghosts change their target in the game by holding SHIFT after the ghosts have begun moving (note that they begin in Scatter mode, not Chase mode).

The orange and red targets mix a lot of the times over pacman to create a red-orangish color;
when the orange ghost gets close, his target will appear in the bottom left as intended. Also note that targets often go off-screen, which is intended, as the original game also had this feature.

Finally, note that the cyan and pink ghost targeting has an odd bug when facing up -- this is also intended, as this is replicating an overflow bug from the original game.



Once the ghost has set their target, they move towards their target through a greedy algorithm. Excluding the direction they came from, they check the tiles around them to see if they can move in that direction. Of the tile directions they can move in, they calculate the distance between their target and the tile, and choose to move in the direction of the tile that has the least distance.

This is a brief overview of the ghost AI -- there are more details in the code comments. You can see these comments where I initialized the ghost chase functions (within the `create` function), the `getValidTiles` function, and the `checkPath` function.

Onto a couple of other aspects:

A good chunk of time was put into making the animation timings the same as the original game, taking up a pretty sizable bulk of the code (see: the code for `startup`, the player colliding with a ghost (`ghostCollide`), resetting the game (`resetEntities`), and the ghost "bounce" that happens when they are spawning (`ghostBounce`)). A lot of this code that seems repetitive was done for the purpose of replicating this animations; otherwise, I would have just skipped over them.

Every frame (if a game-pausing animation is not playing, checked through the `disallow_control` variable), the game runs through a set procedure through the `update` function:

 - Gets Pac-Man's occupied tile's X and Y position

 - Gets the tiles surrounding Pac-Man
 - Checks for input for the player; sets the stored direction for Pac-Man as the inputted direction (arrow keys)
 - Checks if the player can move in that direction (via `checkTurnpoint`)
 - Sets the target tiles for the ghosts (via their `attrs.scatter()` function, `attrs.chase()` function, or by setting it to the tile above the ghost cage)
 - Checks if the ghost is in the Warp Pipe on either side -- if so, reduce their speed
 - Checks for the ghost's next desired direction (through `checkPath`) and if they can currently move in that direction (through `checkTurnpoint`)
 - Checks if the ghost and player have moved past the boundaries of the screen through the warp pipes; if so, put them on the other side of the screen

You may also be wondering why the game is so small on the webpage -- this is because the game uses the original sprites from the original game in their original size (see disclaimer in code).

You can always zoom in using your browser's zoom button or by holding Ctrl and moving the mouse wheel up.

Finally, to end off this technical overview, if I could change one thing about the code, it would have been removing the abundance of global variables contained within (or at least, containing them within an object like I did with the ghost and player attributes).

That would have made the code more organized, but this aspect also did not significantly hinder the development; it is would simply be a better design. This also applies to the functions left out in the open (ie: `startup` or `checkPath`).

Once again, other aspects of the code you may be curious about can be looked into closer via comments in the code. These are simply the most significant parts that require explaining.

Thanks for reading! This project was a lot of work, but it was worth it for the end result. I think I did a good job at recreating the game (if I do say so myself). Enjoy!

