# Pacman50




## Setup

Note: I am not sure of how Gradescope downloading works. If you download the folder directly (no zip file), select the "Upload Folder" option when uploading and ignore the steps about unzipping the folder.

If the files are downloaded individually, put every file into the directories marked on gradescope (pacman50/assets/, pacman50/) and use the "Upload Folder" option and ignore the steps about unzipping the folder.

- Download the pacman50.zip zip file. Log in to CS50 IDE and select the "~/" folder at the top of the file navigator on the left.


- Click "File" at the top right. Select "Upload Local Files" and click "Select files". Navigate to the location of the zip file, select it, and upload the zip file.

- In the terminal, execute `unzip pacman50.zip` to uncompress the folder. Then, execute `rm pacman50.zip` followed by `yes` or `y` to delete the ZIP file.

- Execute `cd pacman50` to change into the directory. Execute the command `ls`. You should see the directory `assets/` along with the files `index.html` and `pacman.js`.

- Execute the command `http-server` and click the link under the text "Available on:". The link should end with "cs50.xyz:8080". Then, click "Open".

- Finally, underneath the header "**Index of /**" should be the directory `assets/` along with the files `index.html` and `pacman.js`. Click `index.html` to enter the game's webpage. Click on or interact in any way with the webpage to start the game.

If so desired, press "Ctrl", hover the mouse cursor over the game, and use the mouse wheel to zoom into the game (the game will probably be tiny!) The game should then become easier to see.

If you wish to see the game's code, you may return to CS50 IDE and open the `pacman.js` folder contained within the `pacman50` directory.

It is (probably) also preferable to play the game in a Chromium-based browser (Google Chrome, Microsoft Edge, etc). I have gotten a couple reports of worse performance in Firefox, though I'm not sure if this is universal,
because I noticed no change in performance when using Firefox.

## How to Play

Pacman50 is a recreation of Pac-Man, so all the same rules apply. Move Pacman around the maze and avoid the ghosts while collecting dots, which are worth ten points each. If Pac-Man runs into a ghost, he will lose a life.

If Pac-Man collects a power pellet (the large dots near the four corners of the map), he can temporarily eat the ghosts to gain lots of points (up to a total of 3000 points if he eats all four ghosts in one go).

If Pac-Man eats all the dots and pellets in one level, he will advance a level and the same process resumes with another batch of dots and pellets.

Once you have lost all your lives (which are indicated in the bottom left of the game UI), the game will end. You can refresh the page to restart (press F5 on your keyboard or locate your browser's refresh button).

Try to get the highest score you can; the current high score is saved via a browser cookie after completing a level and after losing all your lives.

The only controls used for the game are the arrow keys, which move Pacman in the desired direction (up arrow to move up, down arrow to move down, etc).

If Pac-Man cannot move in that direction because it is blocked by a wall, the move will be queued until Pac-Man can move in that direction (or until it is replaced by another direction).

## Video

https://www.youtube.com/watch?v=if_L5vBSdAc&feature=youtu.be